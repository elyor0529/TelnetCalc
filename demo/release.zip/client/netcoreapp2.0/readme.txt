
dotnet run -ip 127.0.0.1 -port 11000 


https://docs.microsoft.com/en-us/dotnet/core/tools/dotnet-run?tabs=netcore2x