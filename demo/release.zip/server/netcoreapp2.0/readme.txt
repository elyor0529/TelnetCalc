dotnet run  -port 11000 

https://docs.microsoft.com/en-us/dotnet/core/tools/dotnet-run?tabs=netcore2x